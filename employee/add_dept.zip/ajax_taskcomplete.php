<?php 
include_once("php_includes/check_login_status.php");
include 'php_includes/db_conx.php';
if($user_ok != true){
    header("location: login.php");
    exit();
}
// After uploading to online server, change this connection accordingly

$title = $_POST['Title'];
// $desc = $_POST['Desc'];
// //$proID = $_POST['pros'];
// $statuss = $_POST['statuss'];

 //echo $proID;
 //echo $statuss;
echo $title;
exit();

$sql_p = "SELECT * FROM task WHERE company_id = '$log_username' AND user_id = '$log_id' AND project_id = '$desc' AND task_id = '$title'";
$query_p = mysqli_query($db_conx, $sql_p);
$count_task = mysqli_num_rows($query_p);
while ($row_p = mysqli_fetch_array($query_p)) {
	# code...
	$task_id = $row_p['task_id'];
    $project_idss = $row_p['project_id'];
	$task_desc = $row_p['task_desc'];

}

if ($count_task == 1) {

	# code...
						$sql_p = "SELECT * FROM task WHERE company_id = '$log_username' AND user_id = '$log_id' AND project_id = '$desc' AND task_desc = '$title'";
						$query_p = mysqli_query($db_conx, $sql_p);
						$count_task = mysqli_num_rows($query_p);
						while ($row_p = mysqli_fetch_array($query_p)) {
							# code...
							$task_id = $row_p['task_id'];
						    $project_idss = $row_p['project_id'];
							$task_desc = $row_p['task_desc'];
							$task_status = $row_p['status'];

										if ($task_status == 0) {
											# code...
											$sql = "UPDATE task SET status = 1 WHERE company_id = '$log_username' AND user_id = '$log_id' AND project_id = '$desc' AND task_desc = '$title' LIMIT 1 ";
											$query = mysqli_query($db_conx, $sql);
																if ($query) {
																	# code...
																	echo '<div class="notification-popup hide">
																			<p>
																				<span class="task">'.$title.'</span>
																				<span class="notification-text"></span>
																			</p>
																		</div>';

																}else{

																	echo "error";

																}

										} 
										elseif ($task_status == 1) {
											# code...
											$sql = "UPDATE task SET status = 2 WHERE company_id = '$log_username' AND user_id = '$log_id' AND project_id = '$desc' AND task_desc = '$title' LIMIT 1";
											$query = mysqli_query($db_conx, $sql);

																if ($query) {
																						# code...
																						echo '<div class="notification-popup hide">
																			<p>
																				<span class="task">'.$title.'</span>
																				<span class="notification-text"></span>
																			</p>
																		</div>';

																					}else{

																						echo "error";

																					}

				                        }

				                        elseif($task_status == 2){

										$sql = "UPDATE task SET status = 0 WHERE company_id = '$log_username' AND user_id = '$log_id' AND project_id = '$desc' AND task_desc = '$title' LIMIT 1";
										$query = mysqli_query($db_conx, $sql);

															if ($query) {
																					# code...
																					echo '<div class="notification-popup hide">
																		<p>
																			<span class="task">'.$title.'</span>
																			<span class="notification-text"></span>
																		</p>
																	</div>';

																				}else{

																					echo "error";

																				}


				                        }

				                        else{

					                          echo "error";


				                         }
				

		
	
	                     }
	
	
	}
	else{

		echo 'error1';
	}
?>

