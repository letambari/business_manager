<!-- include database -->

<?php

  include 'db.php';
 
  // sorry need to get id 

  $id = $_POST['delete_id'];
  echo $id;
  exit();
  $query = mysqli_query($con,"DELETE FROM task WHERE task_id='$id'");

  

 ?>