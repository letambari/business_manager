

<!-- database conncection -->
<?php
 
 $con = mysqli_connect("localhost","root","","sphermanager");
 if(!$con){

    echo "failed to connect";
 }


 ?>