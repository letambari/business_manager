<?php
$conn = mysqli_connect("localhost", "root", "", "sphermanager");
$result = mysqli_query($conn, "SELECT * FROM task");

$data = array();
while ($row = mysqli_fetch_object($result))
{
   // array_push($data, $row);
   $data[] = $row; 

   foreach ($data[0] as $datas) {
   	# code...
   $var = var_dump($datas);

   }
   //var_dump($data[])

echo json_encode( $var );
}

exit();

?>


<?php
$conn = mysqli_connect("localhost", "root", "", "sphermanager");
$result = mysqli_query($conn, "SELECT * FROM task");

$data = array();
while ($row = mysqli_fetch_object($result))
{
 // $okay =  array_push($data, $row);
$okay = $data[] = $row;

$json = json_encode($okay, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);


print_r($json);

}
exit();
?>

<script type="text/javascript">
	// $(document).ready(function(){
	// 	$.getJSON("task.php", function(data))
	// 	 var employee_data = '';
	// 	 $.each(data, function(key, value){
	// 	 	employee_data += '<tr>';
	// 	 })
	// })
</script>
