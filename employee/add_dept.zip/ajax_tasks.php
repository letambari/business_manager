
<?php 
// After uploading to online server, change this connection accordingly

$title = $_POST['Title'];
$desc = $_POST['Desc'];

echo $title;
echo $desc;


?>

