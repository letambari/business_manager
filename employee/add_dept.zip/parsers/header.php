<?php
include_once("php_includes/check_login_status.php");
if($user_ok != true){
    header("location: login.php");
    exit();
}

?>
<?php 

/*function generatekey(){
  $keylength = 8;
  $str = "1234567890abcdefghijklmnopqrstuvwxyz()\|][{}?/><;:";
  $randstr = substr(str_shuffle($str), 0, $keylength);
  return $randstr;
} */

/*function generatekey(){
  //$keylength = 8;
  $randstr = uniqid('destiny', true);
  //$randstr = str_shuffle($str);
  return $randstr;
}
*/

include 'php_includes/db_conx.php';

function checkkeys($db_conx, $randstr){
  $sql = "SELECT username FROM Users";
  $result = mysqli_query($db_conx, $sql);

  while ($row = mysqli_fetch_assoc($result)) {
    if ($row['username'] == $randstr) {
      $keyexists = true;
      break;
    } else{
      $keyexists = false;

    }
    
  }

 // return $keyexists;
}

function generatekey($db_conx){

  $keylength = 8;
  $str ="1234567890abcdefghijklmnopqrstuvwxyz";
  $randstr = substr(str_shuffle($str), 0, $keylength);

  $checkkey = checkkeys($db_conx, $randstr);

  while ($checkkey == true) {
    $randstr = substr(str_shuffle($str), 0, $keylength);
    $checkkey = checkkeys($db_conx, $randstr);
  }

  return $randstr;

}

//echo generatekey($con);


?>
<?php
$CompanyName = '';
$adminPhoto = '';
$adminControl = '';

$id = '';
$ContactPerson = '';
$address = '';
$city = '';
$state_province = '';
$username = '';
$email = '';
$password = '';
$CompanyName = '';
$website = '';
$country = '';
$PostalCode = '';
$phone = '';
$ALTphone = '';
$userlevel = '';
$avatar = '';
$ip = '';
$signup = '';
$lastlogin = '';
$notescheck = '';
$activated = '';
$service = '';
$thetitle = '';
$button = '';
$editdepartment_name2 = '';
$project = '';
$leader_id = '';
$project_id1 = '';
$task = '';
$addtask = '';
$task_status_color = '';
$processing = '';
$project_idss = '';
$taskp = '';
$pri = '';
$sta = '';

if ($user_ok == true) {

  // if ($log_photo != "") {
  //   $adminPhoto = '<img src="user/log_username/'.$log_photo.'" alt="image" class="profile-pic">';
  // }else{
  //   $adminPhoto = '<img src="user/log_username/face15.jpg" alt="image" class="profile-pic">';
  // }
  // $CompanyName = $log_username;
  
}

$count_project = 0;
$count_client = 0;
$count_task = 0;
$count_employee = 0;
$getemp = '';
$getcmp = '';
$getdpt = '';
$getdesgn = '';
$getclient = '';
$getclient2 = '';
$task = '';

$sql_users = "SELECT * FROM users";
$query_users = mysqli_query($db_conx, $sql_users);

 $count_users = mysqli_num_rows($query_users);
// printf("Result set has %d rows.\n",$rowcount)
while ($getusers = mysqli_fetch_array($query_users)) {
	# code...
	
$id = $getusers['id'];
$ContactPerson = $getusers['ContactPerson'];
$address = $getusers['address'];
$city = $getusers['city'];
$state_province = $getusers['state_province'];
$username = $getusers['username'];
$email = $getusers['email'];
$password = $getusers['password'];
$CompanyName = $getusers['CompanyName'];
$website = $getusers['website'];
$country = $getusers['country'];
$PostalCode = $getusers['PostalCode'];
$phone1 = $getusers['phone'];

$userlevel = $getusers['userlevel'];
$avatar = $getusers['avatar'];
$ip = $getusers['ip'];
$signup = $getusers['signup'];
$lastlogin = $getusers['lastlogin'];
$notescheck = $getusers['notescheck'];
$activated = $getusers['activated'];
$service = $getusers['service'];
$ALTphone = $getusers['ALTphone'];







$sql_project_count = "SELECT * FROM project";
$query_project_count = mysqli_query($db_conx, $sql_project_count);

 $count_project = mysqli_num_rows($query_project_count);
// printf("Result set has %d rows.\n",$rowcount)


$sql_count_client = "SELECT * FROM clients WHERE company_id = '$log_username' AND user_id = '$log_id'";
$query_count_client = mysqli_query($db_conx, $sql_count_client);

 $count_client = mysqli_num_rows($query_count_client);
// printf("Result set has %d rows.\n",$rowcount)
 while ($row_count_client = mysqli_fetch_array($query_count_client)) {
 	
 	$client_id = $row_count_client['client_id'];
	$e_firstname = $row_count_client['c_firstname'];
	$e_lastname = $row_count_client['c_lastname'];
	$c_clientID = $row_count_client['c_clientID'];
	$e_email = $row_count_client['c_email'];
	$join_date = $row_count_client['creation_date'];
	$phone = $row_count_client['c_phone'];
	$company = $row_count_client['c_companyname'];
	$user_id = $row_count_client['user_id'];
	$company_id = $row_count_client['company_id'];

	$getclient .= '<div class="col-md-4 col-sm-6 col-12 col-lg-4 col-xl-3">
							<div class="profile-widget">
								<div class="profile-img">
									<a href="client-profile?CLIENTID='.$c_clientID.'" class="avatar"><img src="assets/img/profiles/avatar-06.jpg" alt=""></a>
								</div>
							<!--	<div class="dropdown profile-action">
									<a href="#" class="action-icon dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="material-icons">more_vert</i></a>
                                <div class="dropdown-menu dropdown-menu-right">
                                    <a class="dropdown-item" href="#" data-toggle="modal" data-target="#edit_client"><i class="fa fa-pencil m-r-5"></i> Edit</a>
                                    <a class="dropdown-item" href="#" data-toggle="modal" data-target="#delete_client"><i class="fa fa-trash-o m-r-5"></i> Delete</a>
                                </div>
								</div> -->
								<h4 class="user-name m-t-10 mb-0 text-ellipsis"><a href="client-profile">'.$company.'</a></h4>
								<h5 class="user-name m-t-10 mb-0 text-ellipsis"><a href="client-profile">'.$e_firstname.' '.$e_lastname.'</a></h5>
						<!--		<div class="small text-muted">CEO</div> -->
								<a href="chat" class="btn btn-white btn-sm m-t-10">Message</a>
								<a href="client-profile?CLIENTID='.$c_clientID.'" class="btn btn-white btn-sm m-t-10">View Profile</a>
							</div>
						</div>';

						$getclient2 .= '<tr>
													<td>
														<h2 class="table-avatar">
															<a href="#" class="avatar"><img alt="" src="assets/img/profiles/avatar-19.jpg"></a>
															<a href="client-profile?CLIENTID='.$c_clientID.'">'.$e_firstname.' '.$e_lastname.'<span>'.$company.'</span></a>
														</h2>
													</td>
													<td>'.$e_email.'</td>
													<!--
													<td>
														<div class="dropdown action-label">
															<a class="btn btn-white btn-sm btn-rounded dropdown-toggle" href="#" data-toggle="dropdown" aria-expanded="false">
																<i class="fa fa-dot-circle-o text-success"></i> Active
															</a>
															<div class="dropdown-menu dropdown-menu-right">
																<a class="dropdown-item" href="#"><i class="fa fa-dot-circle-o text-success"></i> Active</a>
																<a class="dropdown-item" href="#"><i class="fa fa-dot-circle-o text-danger"></i> Inactive</a>
															</div>
														</div>
													</td>
												-->
													<td class="text-right">
														<div class="dropdown dropdown-action">
															<a href="#" class="action-icon dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="material-icons">more_vert</i></a>
															<div class="dropdown-menu dropdown-menu-right">
																<a class="dropdown-item" href="javascript:void(0)"><i class="fa fa-pencil m-r-5"></i> Edit</a>
																<a class="dropdown-item" href="javascript:void(0)"><i class="fa fa-trash-o m-r-5"></i> Delete</a>
															</div>
														</div>
													</td>
												</tr>';

}
$sql_count_task = "SELECT * FROM task";
$query_count_task = mysqli_query($db_conx, $sql_count_task);

 $count_task = mysqli_num_rows($query_count_task);
// printf("Result set has %d rows.\n",$rowcount)

 $sql_count_employee = "SELECT * FROM employees WHERE company_id = '$log_username' AND user_id = '$log_id'";
$query_count_employee = mysqli_query($db_conx, $sql_count_employee);



 $count_employee = mysqli_num_rows($query_count_employee);

 while ($row_employee = mysqli_fetch_array($query_count_employee)) {
 	
 	$employee_id = $row_employee['employee_id'];
	$e_firstname = $row_employee['e_firstname'];
	$e_lastname = $row_employee['e_lastname'];
	$e_username = $row_employee['e_username'];
	$e_email = $row_employee['e_email'];
	$e_password = $row_employee['e_password'];
	$e_confirmpassword = $row_employee['e_confirmpassword'];
	$join_date = $row_employee['join_date'];
	$phone = $row_employee['phone'];
	$company = $row_employee['company'];
	$designation = $row_employee['designation'];	
	$e_department = $row_employee['department'];
	$user_id = $row_employee['user_id'];
	$company_id = $row_employee['company_id'];

$sql_count_departments = "SELECT * FROM departments WHERE company_id = '$log_username' AND user_id = '$log_id' AND department_id = '$e_department'";
$query_count_departments = mysqli_query($db_conx, $sql_count_departments);

 $count_departments = mysqli_num_rows($query_count_departments);

 while ($row_departments = mysqli_fetch_array($query_count_departments)) {
 	
 	$department_id = $row_departments['department_id'];
	$department_name = $row_departments['department_name'];
	$company_id = $row_departments['company_id'];
	$user_id = $row_departments['user_id'];


	$getemp .= '<div class="col-md-4 col-sm-6 col-12 col-lg-4 col-xl-3">
							<div class="profile-widget">
								<div class="profile-img">
									<a href="profile?empID='.$employee_id.'" class="avatar"><img src="assets/img/profiles/avatar-08.jpg" alt=""></a>
								</div>
							<!--	<div class="dropdown profile-action">
									<a href="#" class="action-icon dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="material-icons">more_vert</i></a>
									<div class="dropdown-menu dropdown-menu-right">
										<a class="dropdown-item" href="#" data-toggle="modal" data-target="#edit_employee"><i class="fa fa-pencil m-r-5"></i> Edit</a>
										<a class="dropdown-item" href="#" data-toggle="modal" data-target="#delete_employee"><i class="fa fa-trash-o m-r-5"></i> Delete</a>
									</div>
								</div> -->
								<h4 class="user-name m-t-10 mb-0 text-ellipsis"><a href="profile">'.$e_firstname.' '.$e_lastname.'</a></h4>
								<div class="small text-muted">'.$department_name.'</div>
							</div>
						</div>';
 
}
}

 $sql_count_departments = "SELECT * FROM departments WHERE company_id = '$log_username' AND user_id = '$log_id'";
$query_count_departments = mysqli_query($db_conx, $sql_count_departments);

 $count_departments = mysqli_num_rows($query_count_departments);

 while ($row_departments = mysqli_fetch_array($query_count_departments)) {
 	
 	$department_id = $row_departments['department_id'];
	$department_name = $row_departments['department_name'];
	$company_id = $row_departments['company_id'];
	$user_id = $row_departments['user_id'];


	
	


				$getdpt .= '   <tr>
                                            <td>'.$department_id.' </td>
                                            <td>'.$department_name.'</td>
                                            <td class="text-right">
                                            <div class="dropdown dropdown-action">
                                                    <a href="#" class="action-icon dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="material-icons">more_vert</i></a>
                                                <div class="dropdown-menu dropdown-menu-right">
                                                    <a class="dropdown-item" href="editdept?dept='.$department_id.'" ><i class="fa fa-pencil m-r-5"></i> Edit</a>
                                                    <a class="dropdown-item" href="editdept?deletedept='.$department_id.'" ><i class="fa fa-trash-o m-r-5"></i> Delete</a>
                                                </div>
                                                </div>
                                            </td>
                                        </tr>';

 }



 $sql_count_employee = "SELECT * FROM designation WHERE company_id = '$log_username' AND user_id = '$log_id'";
$query_count_employee = mysqli_query($db_conx, $sql_count_employee);



 while ($row_employee = mysqli_fetch_array($query_count_employee)) {
 	
 	$designation_id = $row_employee['designation_id'];
 	$designation_name = $row_employee['designation_name'];
	$department_id = $row_employee['department_id'];
	$company_id = $row_employee['company_id'];
	$user_id = $row_employee['user_id'];

$sql_count_employee2 = "SELECT * FROM departments WHERE company_id = '$log_username' AND user_id = '$log_id' AND department_id = '$department_id'";
$query_count_employee2 = mysqli_query($db_conx, $sql_count_employee2);

 $count_employee2 = mysqli_num_rows($query_count_employee2);

 while ($row_employee2 = mysqli_fetch_array($query_count_employee2)) {
 	
 	
	$department_name2 = $row_employee2['department_name'];
	$company_id2 = $row_employee2['company_id'];
	$user_id2 = $row_employee2['user_id'];

		

	$getdesgn .= '<tbody><tr>
	                    <td>2</td>
											<td>'.$designation_name.'</td>
											<td>'.$department_name2.'</td>
											<td class="text-right">
                                            <div class="dropdown dropdown-action">
													<a href="#" class="action-icon dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="material-icons">more_vert</i></a>
                                                <div class="dropdown-menu dropdown-menu-right">
                                                    <a class="dropdown-item" href="editdept?designaedit='.$designation_id.'" ><i class="fa fa-pencil m-r-5"></i> Edit</a>
                                                    <a class="dropdown-item" href="editdept?designadelete='.$designation_id.'" ><i class="fa fa-trash-o m-r-5"></i> Delete</a>
                                                </div>
												</div>
											</td>
											</tr>
											</tbody>
				';
 }

}}


$sql_p = "SELECT * FROM project WHERE company_id = '$log_username' AND user_id = '$log_id'";
$query_p = mysqli_query($db_conx, $sql_p);
while ($row_p = mysqli_fetch_array($query_p)) {
	# code...
	$project_id = $row_p['project_id'];
    $project_title = $row_p['project_title'];
	$start_date = $row_p['start_date'];
	$end_date = $row_p['end_date'];
	$rate = $row_p['rate'];
	$rate_time = $row_p['rate_time'];
	$priority = $row_p['priority'];
	$description = $row_p['description'];
	$user_id = $row_p['user_id'];
	$company_id = $row_p['company_id'];
	$status = $row_p['Status'];

	 $project .= '<div class="col-lg-4 col-sm-6 col-md-4 col-xl-3">
							<div class="card">
								<div class="card-body">
									<div class="dropdown dropdown-action profile-action">
										<a href="#" class="action-icon dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="material-icons">more_vert</i></a>
										<div class="dropdown-menu dropdown-menu-right">
										<!--	<a class="dropdown-item" href="#" data-toggle="modal" data-target="#edit_project"><i class="fa fa-pencil m-r-5"></i> Edit</a> -->
											<a class="dropdown-item" href="#" data-toggle="modal" data-target="#delete_project"><i class="fa fa-trash-o m-r-5"></i> Delete</a>
										</div>
									</div>
									<h4 class="project-title"><a href="project-view?projectsID='.$project_id.'">'.$project_title.'</a></h4>
									<!-- <small class="block text-ellipsis m-b-15">
										<span class="text-xs">1</span> <span class="text-muted">open tasks, </span>
										<span class="text-xs">9</span> <span class="text-muted">tasks completed</span>
									</small> -->
									<p class="text-muted">'.$description.'
									</p>
									<div class="pro-deadline m-b-15">
										<div class="sub-title">
											Deadline:
										</div>
										<div class="text-muted">
											 '.$end_date.'
										</div>
									</div>
								<!-- 	<div class="project-members m-b-15">
										<div>Project Leader :</div>
										<ul class="team-members">
											<li>
												<a href="#" data-toggle="tooltip" title="Jeffery Lalor"><img alt="" src="assets/img/profiles/avatar-16.jpg"></a>
											</li>
										</ul>
									</div> -->
									<!-- <div class="project-members m-b-15">
										<div>Team :</div>
										<ul class="team-members">
											<li>
												<a href="#" data-toggle="tooltip" title="John Doe"><img alt="" src="assets/img/profiles/avatar-02.jpg"></a>
											</li>
											<li>
												<a href="#" data-toggle="tooltip" title="Richard Miles"><img alt="" src="assets/img/profiles/avatar-09.jpg"></a></a>
											</li>
											<li>
												<a href="#" data-toggle="tooltip" title="John Smith"><img alt="" src="assets/img/profiles/avatar-10.jpg"></a>
											</li>
											<li>
												<a href="#" data-toggle="tooltip" title="Mike Litorus"><img alt="" src="assets/img/profiles/avatar-05.jpg"></a>
											</li>
											<li class="dropdown avatar-dropdown">
												<a href="#" class="all-users dropdown-toggle" data-toggle="dropdown" aria-expanded="false">+15</a>
												<div class="dropdown-menu dropdown-menu-right">
													<div class="avatar-group">
														<a class="avatar avatar-xs" href="#">
															<img alt="" src="assets/img/profiles/avatar-02.jpg">
														</a>
														<a class="avatar avatar-xs" href="#">
															<img alt="" src="assets/img/profiles/avatar-09.jpg">
														</a>
														<a class="avatar avatar-xs" href="#">
															<img alt="" src="assets/img/profiles/avatar-10.jpg">
														</a>
														<a class="avatar avatar-xs" href="#">
															<img alt="" src="assets/img/profiles/avatar-05.jpg">
														</a>
														<a class="avatar avatar-xs" href="#">
															<img alt="" src="assets/img/profiles/avatar-11.jpg">
														</a>
														<a class="avatar avatar-xs" href="#">
															<img alt="" src="assets/img/profiles/avatar-12.jpg">
														</a>
														<a class="avatar avatar-xs" href="#">
															<img alt="" src="assets/img/profiles/avatar-13.jpg">
														</a>
														<a class="avatar avatar-xs" href="#">
															<img alt="" src="assets/img/profiles/avatar-01.jpg">
														</a>
														<a class="avatar avatar-xs" href="#">
															<img alt="" src="assets/img/profiles/avatar-16.jpg">
														</a>
													</div>
													<div class="avatar-pagination">
														<ul class="pagination">
															<li class="page-item">
																<a class="page-link" href="#" aria-label="Previous">
																	<span aria-hidden="true">«</span>
																	<span class="sr-only">Previous</span>
																</a>
															</li>
															<li class="page-item"><a class="page-link" href="#">1</a></li>
															<li class="page-item"><a class="page-link" href="#">2</a></li>
															<li class="page-item">
																<a class="page-link" href="#" aria-label="Next">
																	<span aria-hidden="true">»</span>
																<span class="sr-only">Next</span>
																</a>
															</li>
														</ul>
													</div>
												</div>
											</li>
										</ul>
									</div> -->
									<!-- <p class="m-b-5">Progress <span class="text-success float-right">40%</span></p>
									<div class="progress progress-xs mb-0">
										<div class="progress-bar bg-success" role="progressbar" data-toggle="tooltip" title="40%" style="width: 40%"></div>
									</div> -->
								</div>
							</div>
						</div>';


$sql_c = "SELECT * FROM projectclient WHERE company_id = '$log_username' AND user_id = '$log_id' AND project_id = $project_id";
$query_c = mysqli_query($db_conx, $sql_c);
while ($row_c = mysqli_fetch_array($query_c)) {
	# code...
	$projectclient_id = $row_c['projectclient_id'];
	$project_id1 = $row_c['project_id'];
	$client_id = $row_c['client_id'];
	$user_id = $row_c['user_id'];
	$company_id = $row_c['company_id'];

	if ($project_id1 == $project_id) {
		# code...
	$getit2 = "SELECT * FROM clients WHERE company_id = '$log_username' AND user_id = '$log_id' AND client_id = '$client_id'";

	$query_get2 = mysqli_query($db_conx, $getit2);

	while ($rowclient2 = mysqli_fetch_array($query_get2)) {
		# code...
	$p_client_id = $rowclient2['client_id'];
	$p_firstname = $rowclient2['c_firstname'];
	$p_lastname = $rowclient2['c_lastname'];
	$p_clientID = $rowclient2['c_clientID'];
	$p_email = $rowclient2['c_email'];
	$p_phone = $rowclient2['c_phone'];
	$p_companyname = $rowclient2['c_companyname'];


	}
}
}

}

if (isset($_GET['projectsID'])) {
	# code...
	$projectsID = $_GET['projectsID'];


$sql_ps = "SELECT * FROM project WHERE company_id = '$log_username' AND user_id = '$log_id' AND project_id = '$projectsID'";
$query_ps = mysqli_query($db_conx, $sql_ps);
while ($row_ps = mysqli_fetch_array($query_ps)) {
	# code...
	$project_ids = $row_ps['project_id'];
    $project_titles = $row_ps['project_title'];

	$start_dates = $row_ps['start_date'];
	$end_dates = $row_ps['end_date'];
	$rates = $row_ps['rate'];
	$rate_times = $row_ps['rate_time'];
	$prioritys = $row_ps['priority'];
	$descriptions = $row_ps['description'];
	$user_ids = $row_ps['user_id'];
	$company_ids = $row_ps['company_id'];
	$statuss = $row_ps['Status'];

	if ($prioritys == 'Low') {
		# code...
		$pri .= '<a href="#" class="badge badge-info">'.$prioritys.'</a>';
	} elseif($prioritys == 'Medium'){
        $pri .= '<a href="#" class="badge badge-warning">'.$prioritys.'</a>';

	} else{
		$pri .= '<a href="#" class="badge badge-danger">'.$prioritys.'</a>';
	}

	if ($statuss == 'Completed') {
		# code...
		$sta .= '<a href="#" class="badge badge-success">'.$statuss.'</a>';
	} elseif($statuss == 'On Going'){
        $sta .= '<a href="#" class="badge badge-warning">'.$statuss.'</a>';

	} else{
		$sta .= '<a href="#" class="badge badge-danger">'.$statuss.'</a>';
	}

	$sql_c = "SELECT * FROM projectclient WHERE company_id = '$log_username' AND user_id = '$log_id' AND project_id = '$projectsID'";
$query_c = mysqli_query($db_conx, $sql_c);
while ($row_c = mysqli_fetch_array($query_c)) {
	# code...
	$projectclient_id = $row_c['projectclient_id'];
	$project_id1 = $row_c['project_id'];
	$client_id = $row_c['client_id'];
	$user_id = $row_c['user_id'];
	$company_id = $row_c['company_id'];

	if ($project_id1 == $project_id) {
		# code...
	$getit2 = "SELECT * FROM clients WHERE company_id = '$log_username' AND user_id = '$log_id' AND client_id = '$client_id'";

	$query_get2 = mysqli_query($db_conx, $getit2);

	while ($rowclient2 = mysqli_fetch_array($query_get2)) {
		# code...
	$p_client_id = $rowclient2['client_id'];
	$p_firstname = $rowclient2['c_firstname'];
	$p_lastname = $rowclient2['c_lastname'];
	$p_clientID = $rowclient2['c_clientID'];
	$p_email = $rowclient2['c_email'];


}
	}
}
}
$getit4 = "SELECT * FROM projectleaders WHERE company_id = '$log_username' AND user_id = '$log_id' AND project_id = '$project_id1'";

	$query_get4 = mysqli_query($db_conx, $getit4);

	while ($rowclient4 = mysqli_fetch_array($query_get4)) {
		# code...
	$projectleader_id = $rowclient4['projectleader_id'];
	$pl_project_id = $rowclient4['project_id'];
	$leader_id = $rowclient4['leader_id'];
	$pl_user_id = $rowclient4['user_id'];
	$pl_company_id = $rowclient4['company_id'];


$geteme = "SELECT * FROM employees WHERE company_id = '$log_username' AND user_id = '$log_id' AND employee_id = '$leader_id'";

	$query_geteme = mysqli_query($db_conx, $geteme);

	while ($rowgeteme = mysqli_fetch_array($query_geteme)) {
		# code...
	$peee_employeee_id = $rowgeteme['employee_id'];
	$peee_firstname = $rowgeteme['e_firstname'];
	$peee_lastname = $rowgeteme['e_lastname'];

}
}

}
if (isset($_GET['CLIENTID'])) {
	# code...
	$CLIENTID = $_GET['CLIENTID'];

	$getit = "SELECT * FROM clients WHERE c_clientID = '$CLIENTID'";

	$query_get = mysqli_query($db_conx, $getit);

	while ($rowclient = mysqli_fetch_array($query_get)) {
		# code...
	$profile_client_id = $rowclient['client_id'];
	$profile_e_firstname = $rowclient['c_firstname'];
	$profile_e_lastname = $rowclient['c_lastname'];
	$profile_c_clientID = $rowclient['c_clientID'];
	$profile_e_email = $rowclient['c_email'];
	$profile_join_date = $rowclient['creation_date'];
	$profile_phone = $rowclient['c_phone'];
	$profile_company = $rowclient['c_companyname'];
	$profile_user_id = $rowclient['user_id'];
	$profile_company_id = $rowclient['company_id'];



	}
}

if (isset($_GET['empID'])) {
	# code...
	$empID = $_GET['empID'];

	$getem = "SELECT * FROM employees WHERE employee_id = '$empID'";

	$query_getem = mysqli_query($db_conx, $getem);

	while ($rowgetem = mysqli_fetch_array($query_getem)) {
		# code...
	$ee_employeee_id = $rowgetem['employee_id'];
	$ee_firstname = $rowgetem['e_firstname'];
	$ee_lastname = $rowgetem['e_lastname'];
	$ee_username = $rowgetem['e_username'];
	$ee_email = $rowgetem['e_email'];
	$ee_password = $rowgetem['e_password'];
	$ee_confirmpassword = $rowgetem['e_confirmpassword'];
	$e_join_date = $rowgetem['join_date'];
	$e_phone = $rowgetem['phone'];
	$e_company = $rowgetem['company'];
	$e_designation = $rowgetem['designation'];	
	$e_department = $rowgetem['department'];
	$e_user_id = $rowgetem['user_id'];
	$e_company_id = $rowgetem['company_id'];

$sql_count_edepartments = "SELECT * FROM departments WHERE company_id = '$log_username' AND user_id = '$log_id' AND department_id = '$e_department'";
$query_count_edepartments = mysqli_query($db_conx, $sql_count_edepartments);

 $count_edepartments = mysqli_num_rows($query_count_edepartments);

 while ($row_edepartments = mysqli_fetch_array($query_count_edepartments)) {
 	
 	$edepartment_id = $row_edepartments['department_id'];
	$edepartment_name = $row_edepartments['department_name'];
	$ecompany_id = $row_edepartments['company_id'];
	$euser_id = $row_edepartments['user_id'];

$sql_count_eemployee = "SELECT * FROM designation WHERE company_id = '$log_username' AND user_id = '$log_id' AND designation_id = '$e_designation'";
$query_count_eemployee = mysqli_query($db_conx, $sql_count_eemployee);



 while ($row_eemployee = mysqli_fetch_array($query_count_eemployee)) {
 	
 	$edesignation_id = $row_eemployee['designation_id'];
 	$edesignation_name = $row_eemployee['designation_name'];
	$edepartment_id = $row_eemployee['department_id'];
	$ecompany_id = $row_eemployee['company_id'];
	$euser_id = $row_eemployee['user_id'];

}

}
	}
}

if (isset($_GET['dept'])) {
	# code...
	$dept = $_GET['dept'];


$sql_count_editdept2 = "SELECT * FROM departments WHERE company_id = '$log_username' AND user_id = '$log_id' AND department_id = '$dept'";
$query_count_editdept2 = mysqli_query($db_conx, $sql_count_editdept2);

 $count_editdept2 = mysqli_num_rows($query_count_editdept2);

 while ($row_editdept2 = mysqli_fetch_array($query_count_editdept2)) {
 	
 	
	$editdepartment_name2 = $row_editdept2['department_name'];
	$editdepartment_id2 = $row_editdept2['department_id'];
	$editcompany_id2 = $row_editdept2['company_id'];
	$edituser_id2 = $row_editdept2['user_id'];

	$thetitle .= 'Edit Department';

	$button .= '<button class="btn btn-primary" name="myBtn" type="submit" onclick="ajax_editdept();" type="button">Button</button>
';


//echo $editdepartment_name2;

	}
}


if (isset($_GET['deletedept'])) {
	# code...
	$deletedept = $_GET['deletedept'];


$sql_count_editdept2 = "SELECT * FROM departments WHERE company_id = '$log_username' AND user_id = '$log_id' AND department_id = '$deletedept'";
$query_count_editdept2 = mysqli_query($db_conx, $sql_count_editdept2);

 $count_editdept2 = mysqli_num_rows($query_count_editdept2);

 while ($row_editdept2 = mysqli_fetch_array($query_count_editdept2)) {
 	
 	
	$editdepartment_name2 = $row_editdept2['department_name'];
	$editdepartment_id2 = $row_editdept2['department_id'];
	$editcompany_id2 = $row_editdept2['company_id'];
	$edituser_id2 = $row_editdept2['user_id'];

	$thetitle .= 'Delete Department';

	$button .= '<button class="btn btn-primary" name="myBtn" type="submit" onclick="ajax_deeletedept();" type="button">Button</button>
';

//echo $editdepartment_name2;

	}
}

if (isset($_GET['designaedit'])) {
	# code...
	$designaedit = $_GET['designaedit'];


$sql_count_editdept2 = "SELECT * FROM designation WHERE company_id = '$log_username' AND user_id = '$log_id' AND designation_id = '$designaedit'";
$query_count_editdept2 = mysqli_query($db_conx, $sql_count_editdept2);

 $count_editdept2 = mysqli_num_rows($query_count_editdept2);

 while ($row_editdept2 = mysqli_fetch_array($query_count_editdept2)) {
 	
 	
	$editdepartment_name2 = $row_editdept2['designation_name'];
	$editdepartment_id2 = $row_editdept2['designation_id'];
	$editcompany_id2 = $row_editdept2['company_id'];
	$edituser_id2 = $row_editdept2['user_id'];

	$thetitle .= 'Edit designation';

	$button .= '<button class="btn btn-primary" name="myBtn" type="submit" onclick="ajax_editdesig();" type="button">Button</button>
';

//echo $editdepartment_name2;

	}
}


if (isset($_GET['designadelete'])) {
	# code...
	$designaedit = $_GET['designadelete'];


$sql_count_editdept2 = "SELECT * FROM designation WHERE company_id = '$log_username' AND user_id = '$log_id' AND designation_id = '$designaedit'";
$query_count_editdept2 = mysqli_query($db_conx, $sql_count_editdept2);

 $count_editdept2 = mysqli_num_rows($query_count_editdept2);

 while ($row_editdept2 = mysqli_fetch_array($query_count_editdept2)) {
 	
 	
	$editdepartment_name2 = $row_editdept2['designation_name'];
	$editdepartment_id2 = $row_editdept2['designation_id'];
	$editcompany_id2 = $row_editdept2['company_id'];
	$edituser_id2 = $row_editdept2['user_id'];

	$thetitle .= 'Delete designation';

	$button .= '<button class="btn btn-primary" name="myBtn" type="submit" onclick="ajax_deletedesig();" type="button">Button</button>
';

//echo $editdepartment_name2;

	}
}


if (isset($_GET['pid'])) {
	# code...
	$pid = $_GET['pid'];

$sql_p = "SELECT * FROM task WHERE company_id = '$log_username' AND user_id = '$log_id' AND project_id = '$pid'";
$query_p = mysqli_query($db_conx, $sql_p);
while ($row_p = mysqli_fetch_array($query_p)) {
	# code...
	$task_id = $row_p['task_id'];
    $project_idss = $row_p['project_id'];
	$task_desc = $row_p['task_desc'];

	$task_status = $row_p['status'];

	if ($task_status == 1) {
		# code...
	 $task_status_color = '<li class="task"><div class="task-container">
																		<span class="task-action-btn task-check">
																		<span class="action-circle large complete-btn" title="Mark Complete" id="add-task" name="myBtn" type="submit" onclick="ajax_taskcomplete();" class="action-circle large complete-btn">
																				<i class="material-icons">check</i>
																			</span>';
	} elseif($task_status == 2){

		$task_status_color = '<li class="completed task"><div class="task-container">
																		<span class="task-action-btn task-check">
																		<span class="action-circle large complete-btn" title="Mark ongoing" id="add-task" name="myBtn" type="submit" onclick="ajax_taskcomplete();" class="action-circle large complete-btn">
																				<i class="material-icons">check</i>
																			</span>';
	} else{

		$task_status_color = '<li class="task"><div class="task-container">
																		<span class="task-action-btn task-check">
																		<span class="action-circle large complete-btn" title="Mark Pending" id="add-task" name="myBtn" type="submit" onclick="ajax_taskcomplete();" class="action-circle large complete-btn">
																				<i class="material-icons">check</i>
																			</span>';
	}

	$task .= '<input type="text" name="taskID" id="new-task" value="'.$task_id.'"/>

																			<input type="text" name="taskID2" id="Description2" value="'.$task_desc.'"/>

																			<input type="text" name="taskID2" id="pros" value="'.$project_idss.'"/>

																			<input type="text" name="status" id="statuss" value="'.$task_status.'"/>
																			'.$task_status_color.'
																		</span>
																		
																		<span class="task-label" contenteditable="true">'.$task_desc.'</span>
																		<span class="task-action-btn task-btn-right">
																			<span class="action-circle large" title="Assign">
																				<i class="material-icons">person_add</i>
																			</span>
																			<span class="action-circle large delete-btn" title="Delete Task">
																				<a href="deletetask?task_id='.$task_id.'&tasktitile='.$task_desc.'&companyID='.$log_username.'&userID='.$log_id.'&project_id='.$project_idss.'">
																				<i class="material-icons">delete</i>
																				</a>
																			</span>
																		</span>
																	</div>
																	</li>
	';


}
$addtask .= '<span class="add-task-btn btn btn-white btn-sm">
													Add Task
												</span>';
}

	
else {
$sql_p = "SELECT * FROM task";
$query_p = mysqli_query($db_conx, $sql_p);
while ($row_p = mysqli_fetch_array($query_p)) {
	# code...
	$task_id = $row_p['task_id'];
    $project_idss = $row_p['project_id'];
	$task_desc = $row_p['task_desc'];
	$task_status = $row_p['status'];

	if ($task_status == 1) {
		# code...
	 $task_status_color = '<li class="task"><div class="task-container">
																		<span class="task-action-btn task-check">
																		<span class="action-circle large complete-btn" title="Mark Complete" id="add-task" name="myBtn" type="submit" onclick="ajax_taskcomplete();" class="action-circle large complete-btn">
																				<i class="material-icons">check</i>
																			</span>';
	} elseif($task_status == 2){

		$task_status_color = '<li class="completed task"><div class="task-container">
																		<span class="task-action-btn task-check">
																		<span class="action-circle large complete-btn" title="Mark Complete" id="add-task" name="myBtn" type="submit" onclick="ajax_taskcomplete();" class="action-circle large complete-btn">
																				<i class="material-icons">check</i>
																			</span>';
	} else{

		$task_status_color = '<li class="task"><div class="task-container">
																		<span class="task-action-btn task-check">
																		<span class="action-circle large complete-btn" title="Mark Complete" id="add-task" name="myBtn" type="submit" onclick="ajax_taskcomplete();" class="action-circle large complete-btn">
																				<i class="material-icons">check</i>
																			</span>';
		$processing = '<div id="status">
																</div>';
	}

	$task .= '
																			<input type="text" name="taskID" id="new-task" value="'.$task_id.'"/>

																			<input type="text" name="taskID2" id="Description2" value="'.$task_desc.'"/>

																			

																			<input type="text" name="status" id="statuss" value="'.$task_status.'"/>
																			<input type="text" name="taskID2" id="pros" value="'.$project_idss.'"/>
																			'.$task_status_color.'
																		</span>
																		
																		<span class="task-label" contenteditable="true">'.$task_desc.'</span>
																		<span class="task-action-btn task-btn-right">
																			<span class="action-circle large" title="Assign">
																				<i class="material-icons">person_add</i>
																			</span>
																			<span class="action-circle large delete-btn" title="Delete Task">
																				<a href="deletetask?task_id='.$task_id.'&tasktitile='.$task_desc.'&companyID='.$log_username.'&userID='.$log_id.'&project_id='.$project_idss.'">
																				<i class="material-icons">delete</i>
																				</a>
																			</span>
																		</span>
																	</div>
																	</li>
	';
}
}
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
        <meta name="description" content="Smarthr - Bootstrap Admin Template">
		<meta name="keywords" content="admin, estimates, bootstrap, business, corporate, creative, management, minimal, modern, accounts, invoice, html5, responsive, CRM, Projects">
        <meta name="author" content="Dreamguys - Bootstrap Admin Template">
        <meta name="robots" content="nohome, nofollow">
        <title>Employees - HRMS admin template</title>
		
		<!-- Favicon -->
        <link rel="shortcut icon" type="image/x-icon" href="assets/img/favicon.png">
		
		<!-- Bootstrap CSS -->
        <link rel="stylesheet" href="assets/css/bootstrap.min.css">
		
		<!-- Fontawesome CSS -->
        <link rel="stylesheet" href="assets/css/font-awesome.min.css">
		
		<!-- Lineawesome CSS -->
        <link rel="stylesheet" href="assets/css/line-awesome.min.css">
		
		<!-- Select2 CSS -->
		<link rel="stylesheet" href="assets/css/select2.min.css">
		
		<!-- Datetimepicker CSS -->
		<link rel="stylesheet" href="assets/css/bootstrap-datetimepicker.min.css">

		<!-- Summernote CSS -->
		<link rel="stylesheet" href="assets/plugins/summernote/dist/summernote-bs4.css">
		
		<!-- Main CSS -->
        <link rel="stylesheet" href="assets/css/style.css">

        
<!-- Favicon -->

        <link rel="shortcut icon" type="image/x-icon" href="assets/img/favicon.png">
		
		<!-- Bootstrap CSS -->
        <link rel="stylesheet" href="assets/css/bootstrap.min.css">
		
		<!-- Fontawesome CSS -->
        <link rel="stylesheet" href="assets/css/font-awesome.min.css">
		
		<!-- Lineawesome CSS -->
        <link rel="stylesheet" href="assets/css/line-awesome.min.css">
		
		<!-- Datatable CSS -->
		<link rel="stylesheet" href="assets/css/dataTables.bootstrap4.min.css">
		
		<!-- Main CSS -->
        <link rel="stylesheet" href="assets/css/style.css">
        			
		<!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
		<!--[if lt IE 9]>
			<script src="assets/js/html5shiv.min.js"></script>
			<script src="assets/js/respond.min.js"></script>
		<![endif]-->
		<script>
function ajax_post(){
    // Create our XMLHttpRequest object
    var hr = new XMLHttpRequest();
    // Create some variables we need to send to our PHP file
    var url = "add_dept.php";
    var tl = document.getElementById("title").value;
    // var us = document.getElementById("userID").value;
    // var cc = document.getElementById("company_code").value;
    // +"&userID="+us+"&company_code="+cc
    var vars = "Title="+tl;
    hr.open("POST", url, true);
    // Set content type header information for sending url encoded variables in the request
    hr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    // Access the onreadystatechange event for the XMLHttpRequest object
    hr.onreadystatechange = function() {
        if(hr.readyState == 4 && hr.status == 200) {
            var return_data = hr.responseText;
            document.getElementById("status").innerHTML = return_data;
        }
    }
    // Send the data to PHP now... and wait for response to update the status div
    hr.send(vars); // Actually execute the request
    document.getElementById("status").innerHTML = "<img src='assets/img/preloader.gif' alt='Processing...'>";
}
</script>
<script>
function ajax_desgn(){
    // Create our XMLHttpRequest object
    var hr = new XMLHttpRequest();
    // Create some variables we need to send to our PHP file
    var url = "try2.php";
    var tl = document.getElementById("title").value;
    var us = document.getElementById("userID").value;
    var cc = document.getElementById("company_code").value;
    var dp = document.getElementById("deptID").value;
    var vars = "Title="+tl+"&userID="+us+"&company_code="+cc+"&deptID="+dp;
    hr.open("POST", url, true);
    // Set content type header information for sending url encoded variables in the request
    hr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    // Access the onreadystatechange event for the XMLHttpRequest object
    hr.onreadystatechange = function() {
        if(hr.readyState == 4 && hr.status == 200) {
            var return_data = hr.responseText;
            document.getElementById("status").innerHTML = return_data;
        }
    }
    // Send the data to PHP now... and wait for response to update the status div
    hr.send(vars); // Actually execute the request
    document.getElementById("status").innerHTML = "<img src='assets/img/preloader.gif' alt='Processing...'>";
}
</script>

<script>
function ajax_posts(){
    // Create our XMLHttpRequest object
    var hr = new XMLHttpRequest();
    // Create some variables we need to send to our PHP file
    var url = "ajax_employ.php";
    var fn = document.getElementById("FirstName").value;
    var ln = document.getElementById("LastName").value;
    var us = document.getElementById("userID").value;
    var cc = document.getElementById("company_code").value;
    var em = document.getElementById("email").value;
    var pd = document.getElementById("password").value;
    var rp = document.getElementById("re_password").value;
    var ep = document.getElementById("employee_id").value;
    var jd = document.getElementById("join_date").value;
    var ph = document.getElementById("phone").value;
    var cm = document.getElementById("company").value;
    var dp = document.getElementById("department").value;
    var ds = document.getElementById("designation").value;
    var vars = "FirstName="+fn+"&LastName="+ln+"&userID="+us+"&company_code="+cc+"&email="+em+"&password="+pd+"&re_password="+rp+"&employee_id="+ep+"&join_date="+jd+"&phone="+ph+"&company="+cm+"&department="+dp+"&designation="+ds;
    hr.open("POST", url, true);
    // Set content type header information for sending url encoded variables in the request
    hr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    // Access the onreadystatechange event for the XMLHttpRequest object
    hr.onreadystatechange = function() {
        if(hr.readyState == 4 && hr.status == 200) {
            var return_data = hr.responseText;
            document.getElementById("status").innerHTML = return_data;
        }
    }
    // Send the data to PHP now... and wait for response to update the status div
    hr.send(vars); // Actually execute the request
    document.getElementById("status").innerHTML = "<img src='assets/img/preloader.gif' alt='Processing...'>";
}
</script>

<script>
function ajax_client(){
    // Create our XMLHttpRequest object
    var hr = new XMLHttpRequest();
    // Create some variables we need to send to our PHP file
    var url = "ajax_client.php";
    var fn = document.getElementById("FirstName").value;
    var ln = document.getElementById("LastName").value;
    var us = document.getElementById("userID").value;
    var cc = document.getElementById("company_code").value;
    var em = document.getElementById("email").value;
    var ep = document.getElementById("employee_id").value;
    var ph = document.getElementById("phone").value;
    var cm = document.getElementById("company").value;
    var vars = "FirstName="+fn+"&LastName="+ln+"&userID="+us+"&company_code="+cc+"&email="+em+"&employee_id="+ep+"&phone="+ph+"&company="+cm;
    hr.open("POST", url, true);
    // Set content type header information for sending url encoded variables in the request
    hr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    // Access the onreadystatechange event for the XMLHttpRequest object
    hr.onreadystatechange = function() {
        if(hr.readyState == 4 && hr.status == 200) {
            var return_data = hr.responseText;
            document.getElementById("status").innerHTML = return_data;
        }
    }
    // Send the data to PHP now... and wait for response to update the status div
    hr.send(vars); // Actually execute the request
    document.getElementById("status").innerHTML = "<img src='assets/img/preloader.gif' alt='Processing...'>";
}
</script>


<script>
function ajax_sett(){
    // Create our XMLHttpRequest object
    var hr = new XMLHttpRequest();
    // Create some variables we need to send to our PHP file
    var url = "ajax_sett.php";
    var cn = document.getElementById("CompanyName").value;
    var cp = document.getElementById("ContactPerson").value;
    var ad = document.getElementById("address").value;
    var cu = document.getElementById("country").value;
    var em = document.getElementById("email").value;
    var ct = document.getElementById("city").value;
    var ph = document.getElementById("phone").value;
    var sp = document.getElementById("state_province").value;
    var us = document.getElementById("username").value;
    var wb = document.getElementById("website").value;
    var pc = document.getElementById("PostalCode").value;
    var ap = document.getElementById("ALTphone").value;
    var vars = "CompanyName="+cn+"&ContactPerson="+cp+"&address="+ad+"&country="+cu+"&email="+em+"&city="+ct+"&phone="+ph+"&state_province="+sp+"&username="+us+"&website="+wb+"&PostalCode="+pc+"&ALTphone="+ap;
    hr.open("POST", url, true);
    // Set content type header information for sending url encoded variables in the request
    hr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    // Access the onreadystatechange event for the XMLHttpRequest object
    hr.onreadystatechange = function() {
        if(hr.readyState == 4 && hr.status == 200) {
            var return_data = hr.responseText;
            document.getElementById("status").innerHTML = return_data;
        }
    }
    // Send the data to PHP now... and wait for response to update the status div
    hr.send(vars); // Actually execute the request
    document.getElementById("status").innerHTML = "<img src='assets/img/preloader.gif' alt='Processing...'>";
}
</script>

<script>
function ajax_edit(){
    // Create our XMLHttpRequest object
    var hr = new XMLHttpRequest();
    // Create some variables we need to send to our PHP file
    var url = "ajax_employedit.php";
    var fn = document.getElementById("firstName").value;
     var ln = document.getElementById("lastname").value;
     var em = document.getElementById("email").value;
     var ep = document.getElementById("employee_id").value;
     var ph = document.getElementById("phone").value;
     var dp = document.getElementById("dept").value;
     var ds = document.getElementById("desig").value;
    var vars = "firstName="+fn+"&lastname="+ln+"&employee_id="+ep+"&email="+em+"&phone="+ph+"&dept="+dp+"&desig="+ds;
    hr.open("POST", url, true);
    // Set content type header information for sending url encoded variables in the request
    hr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    // Access the onreadystatechange event for the XMLHttpRequest object
    hr.onreadystatechange = function() {
        if(hr.readyState == 4 && hr.status == 200) {
            var return_data = hr.responseText;
            document.getElementById("status").innerHTML = return_data;
        }
    }
    // Send the data to PHP now... and wait for response to update the status div
    hr.send(vars); // Actually execute the request
    document.getElementById("status").innerHTML = "<img src='assets/img/preloader.gif' alt='Processing...'>";
}
</script>

<script>
function ajax_editclient(){
    // Create our XMLHttpRequest object
    var hr = new XMLHttpRequest();
    // Create some variables we need to send to our PHP file
    var url = "ajax_editclient.php";
    var fn = document.getElementById("firstName").value;
     var ln = document.getElementById("lastname").value;
     var em = document.getElementById("email").value;
     var ep = document.getElementById("employee_id").value;
     var ph = document.getElementById("phone").value;
     var dp = document.getElementById("company").value;
     var ed = document.getElementById("employee_code").value;
    var vars = "firstName="+fn+"&lastname="+ln+"&employee_id="+ep+"&email="+em+"&phone="+ph+"&company="+dp+"&employee_code="+ed;
    hr.open("POST", url, true);
    // Set content type header information for sending url encoded variables in the request
    hr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    // Access the onreadystatechange event for the XMLHttpRequest object
    hr.onreadystatechange = function() {
        if(hr.readyState == 4 && hr.status == 200) {
            var return_data = hr.responseText;
            document.getElementById("status").innerHTML = return_data;
        }
    }
    // Send the data to PHP now... and wait for response to update the status div
    hr.send(vars); // Actually execute the request
    document.getElementById("status").innerHTML = "<img src='assets/img/preloader.gif' alt='Processing...'>";
}
</script>

<script>
function ajax_deeletedept(){
    // Create our XMLHttpRequest object
    var hr = new XMLHttpRequest();
    // Create some variables we need to send to our PHP file
    var url = "ajax_deeletedept.php";
    var ed = document.getElementById("editdept").value;
    var eii = document.getElementById("editdeptid").value;
     
    var vars = "editdept="+ed+"&editdeptid="+eii;
    hr.open("POST", url, true);
    // Set content type header information for sending url encoded variables in the request
    hr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    // Access the onreadystatechange event for the XMLHttpRequest object
    hr.onreadystatechange = function() {
        if(hr.readyState == 4 && hr.status == 200) {
            var return_data = hr.responseText;
            document.getElementById("status").innerHTML = return_data;
        }
    }
    // Send the data to PHP now... and wait for response to update the status div
    hr.send(vars); // Actually execute the request
    document.getElementById("status").innerHTML = "<img src='assets/img/preloader.gif' alt='Processing...'>";
}
</script>

<script>
function ajax_editdept(){
    // Create our XMLHttpRequest object
    var hr = new XMLHttpRequest();
    // Create some variables we need to send to our PHP file
    var url = "ajax_editdept.php";
    var ed = document.getElementById("editdept").value;
    var eii = document.getElementById("editdeptid").value;
     
    var vars = "editdept="+ed+"&editdeptid="+eii;
    hr.open("POST", url, true);
    // Set content type header information for sending url encoded variables in the request
    hr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    // Access the onreadystatechange event for the XMLHttpRequest object
    hr.onreadystatechange = function() {
        if(hr.readyState == 4 && hr.status == 200) {
            var return_data = hr.responseText;
            document.getElementById("status").innerHTML = return_data;
        }
    }
    // Send the data to PHP now... and wait for response to update the status div
    hr.send(vars); // Actually execute the request
    document.getElementById("status").innerHTML = "<img src='assets/img/preloader.gif' alt='Processing...'>";
}
</script>

<script>
function ajax_editdesig(){
    // Create our XMLHttpRequest object
    var hr = new XMLHttpRequest();
    // Create some variables we need to send to our PHP file
    var url = "ajax_editdesig.php";
    var ed = document.getElementById("editdept").value;
    var eii = document.getElementById("editdeptid").value;
     
    var vars = "editdept="+ed+"&editdeptid="+eii;
    hr.open("POST", url, true);
    // Set content type header information for sending url encoded variables in the request
    hr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    // Access the onreadystatechange event for the XMLHttpRequest object
    hr.onreadystatechange = function() {
        if(hr.readyState == 4 && hr.status == 200) {
            var return_data = hr.responseText;
            document.getElementById("status").innerHTML = return_data;
        }
    }
    // Send the data to PHP now... and wait for response to update the status div
    hr.send(vars); // Actually execute the request
    document.getElementById("status").innerHTML = "<img src='assets/img/preloader.gif' alt='Processing...'>";
}
</script>

<script>
function ajax_deletedesig(){
    // Create our XMLHttpRequest object
    var hr = new XMLHttpRequest();
    // Create some variables we need to send to our PHP file
    var url = "ajax_deletedesig.php";
    var ed = document.getElementById("editdept").value;
    var eii = document.getElementById("editdeptid").value;
     
    var vars = "editdept="+ed+"&editdeptid="+eii;
    hr.open("POST", url, true);
    // Set content type header information for sending url encoded variables in the request
    hr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    // Access the onreadystatechange event for the XMLHttpRequest object
    hr.onreadystatechange = function() {
        if(hr.readyState == 4 && hr.status == 200) {
            var return_data = hr.responseText;
            document.getElementById("status").innerHTML = return_data;
        }
    }
    // Send the data to PHP now... and wait for response to update the status div
    hr.send(vars); // Actually execute the request
    document.getElementById("status").innerHTML = "<img src='assets/img/preloader.gif' alt='Processing...'>";
}
</script>

<script>
function ajax_project(){
    // Create our XMLHttpRequest object
    var hr = new XMLHttpRequest();
    // Create some variables we need to send to our PHP file
    var url = "ajax_project.php";
    var pn = document.getElementById("project_name").value;
    var cl = document.getElementById("client").value;
    var ed = document.getElementById("end_date").value;
    // var dt = document.getElementById("date").value;
    var rt = document.getElementById("rate").value;
    var pr = document.getElementById("Priority").value;
    var pl = document.getElementById("project_lead").value;
    var de = document.getElementById("Description").value;
    // var fi = document.getElementById("file").value; +"&file="+fi
    var us = document.getElementById("userID").value;
    var cm = document.getElementById("company_id").value;
    var st = document.getElementById("start").value;
    
    
    
    
    
     
    var vars = "project_name="+pn+"&client="+cl+"&end_date="+ed+"&rate="+rt+"&Priority="+pr+"&project_lead="+pl+"&Description="+de+"&userID="+us+"&company_id="+cm+"&start="+st;
    hr.open("POST", url, true);
    // Set content type header information for sending url encoded variables in the request
    hr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    // Access the onreadystatechange event for the XMLHttpRequest object
    hr.onreadystatechange = function() {
        if(hr.readyState == 4 && hr.status == 200) {
            var return_data = hr.responseText;
            document.getElementById("status").innerHTML = return_data;
        }
    }
    // Send the data to PHP now... and wait for response to update the status div
    hr.send(vars); // Actually execute the request
    document.getElementById("status").innerHTML = "<img src='assets/img/preloader.gif' alt='Processing...'>";
}
</script>

<script>
function ajax_projectedit(){
    // Create our XMLHttpRequest object
    var hr = new XMLHttpRequest();
    // Create some variables we need to send to our PHP file
    var url = "ajax_projectedit.php";
    var pn = document.getElementById("project_name").value;
    var cl = document.getElementById("client").value;
    var ed = document.getElementById("end_date").value;
    // var dt = document.getElementById("date").value;
    var rt = document.getElementById("rate").value;
    var pr = document.getElementById("Priority").value;
    var pl = document.getElementById("project_lead").value;
    var de = document.getElementById("Description").value;
    // var fi = document.getElementById("file").value; +"&file="+fi
    var us = document.getElementById("userID").value;
    var cm = document.getElementById("company_id").value;
    var st = document.getElementById("start").value;
    var pi = document.getElementById("project_id").value;
    

    var vars = "project_name="+pn+"&client="+cl+"&end_date="+ed+"&rate="+rt+"&Priority="+pr+"&project_lead="+pl+"&Description="+de+"&userID="+us+"&company_id="+cm+"&start="+st+"&project_id="+pi;
    hr.open("POST", url, true);
    // Set content type header information for sending url encoded variables in the request
    hr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    // Access the onreadystatechange event for the XMLHttpRequest object
    hr.onreadystatechange = function() {
        if(hr.readyState == 4 && hr.status == 200) {
            var return_data = hr.responseText;
            document.getElementById("status").innerHTML = return_data;
        }
    }
    // Send the data to PHP now... and wait for response to update the status div
    hr.send(vars); // Actually execute the request
    document.getElementById("status").innerHTML = "<img src='assets/img/preloader.gif' alt='Processing...'>";
}
</script>


<script>
function ajax_task(){
    // Create our XMLHttpRequest object
    var hr = new XMLHttpRequest();
    // Create some variables we need to send to our PHP file
    var url = "ajax_task.php";
    var nt = document.getElementById("newtask").value;
   

    var vars = "newtask="+nt;
    hr.open("POST", url, true);
    // Set content type header information for sending url encoded variables in the request
    hr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    // Access the onreadystatechange event for the XMLHttpRequest object
    hr.onreadystatechange = function() {
        if(hr.readyState == 4 && hr.status == 200) {
            var return_data = hr.responseText;
            document.getElementById("status").innerHTML = return_data;
        }
    }
    // Send the data to PHP now... and wait for response to update the status div
    hr.send(vars); // Actually execute the request
    document.getElementById("status").innerHTML = "<img src='assets/img/preloader.gif' alt='Processing...'>";
}
</script>

<script>
function ajax_tasks(){
    // Create our XMLHttpRequest object
    var hr = new XMLHttpRequest();
    // Create some variables we need to send to our PHP file
    var url = "my_parse_file.php";
    var fn = document.getElementById("new-task").value;
    var ln = document.getElementById("Description2").value;
    // var id = document.getElementById("id").value;
    var vars = "Title="+fn+"&Desc="+ln;
    hr.open("POST", url, true);
    // Set content type header information for sending url encoded variables in the request
    hr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    // Access the onreadystatechange event for the XMLHttpRequest object
    hr.onreadystatechange = function() {
	    if(hr.readyState == 4 && hr.status == 200) {
		    var return_data = hr.responseText;
			document.getElementById("status").innerHTML = return_data;
	    }
    }
    // Send the data to PHP now... and wait for response to update the status div
    hr.send(vars); // Actually execute the request
    document.getElementById("status").innerHTML = "<img src='assets/img/preloader.gif' alt='Processing...'>";
}
</script>

<script>
function ajax_tasks(){
    // Create our XMLHttpRequest object
    var hr = new XMLHttpRequest();
    // Create some variables we need to send to our PHP file
    var url = "my_parse_file.php";
    var fn = document.getElementById("new-task").value;
    var ln = document.getElementById("Description2").value;
    // var id = document.getElementById("id").value;
    var vars = "Title="+fn+"&Desc="+ln;
    hr.open("POST", url, true);
    // Set content type header information for sending url encoded variables in the request
    hr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    // Access the onreadystatechange event for the XMLHttpRequest object
    hr.onreadystatechange = function() {
	    if(hr.readyState == 4 && hr.status == 200) {
		    var return_data = hr.responseText;
			document.getElementById("status").innerHTML = return_data;
	    }
    }
    // Send the data to PHP now... and wait for response to update the status div
    hr.send(vars); // Actually execute the request
    document.getElementById("status").innerHTML = "<img src='assets/img/preloader.gif' alt='Processing...'>";
}
</script>

<script>
function ajax_taskcomplete(){
    // Create our XMLHttpRequest object
    var hr = new XMLHttpRequest();
    // Create some variables we need to send to our PHP file
    var url = "ajax_taskcomplete.php";
    var fn = document.getElementById("new-task").value;
    // var ln = document.getElementById("Description2").value;
     
    // var st = document.getElementById("statuss").value;
    // var pd = document.getElementById("pros").value;
    // var id = document.getElementById("id").value;
    //+"&Desc="+ln+"&statuss="+st+"pros="+pd
    var vars = "Title="+fn;
    hr.open("POST", url, true);
    // Set content type header information for sending url encoded variables in the request
    hr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    // Access the onreadystatechange event for the XMLHttpRequest object
    hr.onreadystatechange = function() {
	    if(hr.readyState == 4 && hr.status == 200) {
		    var return_data = hr.responseText;
			document.getElementById("status").innerHTML = return_data;
	    }
    }
    // Send the data to PHP now... and wait for response to update the status div
    hr.send(vars); // Actually execute the request
    document.getElementById("status").innerHTML = "<img src='assets/img/preloader.gif' alt='Processing...'>";
}
</script>

    </head>
    <body>
		<!-- Main Wrapper -->
        <div class="main-wrapper">
		
			<!-- Header -->
            <div class="header">
			
				<!-- Logo -->
                <div class="header-left">
                    <a href="home" class="logo">
						<img src="assets/img/logo.png" width="40" height="40" alt="">
					</a>
                </div>
				<!-- /Logo -->
				
				<a id="toggle_btn" href="javascript:void(0);">
					<span class="bar-icon">
						<span></span>
						<span></span>
						<span></span>
					</span>
				</a>
				
				<!-- Header Title -->
                <div class="page-title-box">
					<h3><?php echo $CompanyName; ?></h3>
                </div>
				<!-- /Header Title -->
				
				<a id="mobile_btn" class="mobile_btn" href="#sidebar"><i class="fa fa-bars"></i></a>
				
				<!-- Header Menu -->
				<ul class="nav user-menu">
				
					<!-- Search -->
					<li class="nav-item">
						<div class="top-nav-search">
							<a href="javascript:void(0);" class="responsive-search">
								<i class="fa fa-search"></i>
						   </a>
							<form action="search">
								<input class="form-control" type="text" placeholder="Search here">
								<button class="btn" type="submit"><i class="fa fa-search"></i></button>
							</form>
						</div>
					</li>
					<!-- /Search -->
				
					<!-- Flag -->
					<li class="nav-item dropdown has-arrow flag-nav">
						<a class="nav-link dropdown-toggle" data-toggle="dropdown" href="#" role="button">
							<img src="assets/img/flags/us.png" alt="" height="20"> <span>English</span>
						</a>
						<div class="dropdown-menu dropdown-menu-right">
							<a href="javascript:void(0);" class="dropdown-item">
								<img src="assets/img/flags/us.png" alt="" height="16"> English
							</a>
							<a href="javascript:void(0);" class="dropdown-item">
								<img src="assets/img/flags/fr.png" alt="" height="16"> French
							</a>
							<a href="javascript:void(0);" class="dropdown-item">
								<img src="assets/img/flags/es.png" alt="" height="16"> Spanish
							</a>
							<a href="javascript:void(0);" class="dropdown-item">
								<img src="assets/img/flags/de.png" alt="" height="16"> German
							</a>
						</div>
					</li>
					<!-- /Flag -->
					
					<!-- Notifications -->
					<!--
					<li class="nav-item dropdown">
						<a href="#" class="dropdown-toggle nav-link" data-toggle="dropdown">
							<i class="fa fa-bell-o"></i> <span class="badge badge-pill">3</span>
						</a>
						<div class="dropdown-menu notifications">
							<div class="topnav-dropdown-header">
								<span class="notification-title">Notifications</span>
								<a href="javascript:void(0)" class="clear-noti"> Clear All </a>
							</div>
							<div class="noti-content">
								<ul class="notification-list">
									<li class="notification-message">
										<a href="activities">
											<div class="media">
												<span class="avatar">
													<img alt="" src="assets/img/profiles/avatar-02.jpg">
												</span>
												<div class="media-body">
													<p class="noti-details"><span class="noti-title">John Doe</span> added new task <span class="noti-title">Patient appointment booking</span></p>
													<p class="noti-time"><span class="notification-time">4 mins ago</span></p>
												</div>
											</div>
										</a>
									</li>
									<li class="notification-message">
										<a href="activities">
											<div class="media">
												<span class="avatar">
													<img alt="" src="assets/img/profiles/avatar-03.jpg">
												</span>
												<div class="media-body">
													<p class="noti-details"><span class="noti-title">Tarah Shropshire</span> changed the task name <span class="noti-title">Appointment booking with payment gateway</span></p>
													<p class="noti-time"><span class="notification-time">6 mins ago</span></p>
												</div>
											</div>
										</a>
									</li>
									<li class="notification-message">
										<a href="activities">
											<div class="media">
												<span class="avatar">
													<img alt="" src="assets/img/profiles/avatar-06.jpg">
												</span>
												<div class="media-body">
													<p class="noti-details"><span class="noti-title">Misty Tison</span> added <span class="noti-title">Domenic Houston</span> and <span class="noti-title">Claire Mapes</span> to project <span class="noti-title">Doctor available module</span></p>
													<p class="noti-time"><span class="notification-time">8 mins ago</span></p>
												</div>
											</div>
										</a>
									</li>
									<li class="notification-message">
										<a href="activities">
											<div class="media">
												<span class="avatar">
													<img alt="" src="assets/img/profiles/avatar-17.jpg">
												</span>
												<div class="media-body">
													<p class="noti-details"><span class="noti-title">Rolland Webber</span> completed task <span class="noti-title">Patient and Doctor video conferencing</span></p>
													<p class="noti-time"><span class="notification-time">12 mins ago</span></p>
												</div>
											</div>
										</a>
									</li>
									<li class="notification-message">
										<a href="activities">
											<div class="media">
												<span class="avatar">
													<img alt="" src="assets/img/profiles/avatar-13.jpg">
												</span>
												<div class="media-body">
													<p class="noti-details"><span class="noti-title">Bernardo Galaviz</span> added new task <span class="noti-title">Private chat module</span></p>
													<p class="noti-time"><span class="notification-time">2 days ago</span></p>
												</div>
											</div>
										</a>
									</li>
								</ul>
							</div>
							<div class="topnav-dropdown-footer">
								<a href="activities">View all Notifications</a>
							</div>
						</div>
					</li>
				-->
					<!-- /Notifications -->
					
					<!-- Message Notifications -->
					<!--
					<li class="nav-item dropdown">
						<a href="#" class="dropdown-toggle nav-link" data-toggle="dropdown">
							<i class="fa fa-comment-o"></i> <span class="badge badge-pill">8</span>
						</a>
						<div class="dropdown-menu notifications">
							<div class="topnav-dropdown-header">
								<span class="notification-title">Messages</span>
								<a href="javascript:void(0)" class="clear-noti"> Clear All </a>
							</div>
							<div class="noti-content">
								<ul class="notification-list">
									<li class="notification-message">
										<a href="chat">
											<div class="list-item">
												<div class="list-left">
													<span class="avatar">
														<img alt="" src="assets/img/profiles/avatar-09.jpg">
													</span>
												</div>
												<div class="list-body">
													<span class="message-author">Richard Miles </span>
													<span class="message-time">12:28 AM</span>
													<div class="clearfix"></div>
													<span class="message-content">Lorem ipsum dolor sit amet, consectetur adipiscing</span>
												</div>
											</div>
										</a>
									</li>
									<li class="notification-message">
										<a href="chat">
											<div class="list-item">
												<div class="list-left">
													<span class="avatar">
														<img alt="" src="assets/img/profiles/avatar-02.jpg">
													</span>
												</div>
												<div class="list-body">
													<span class="message-author">John Doe</span>
													<span class="message-time">6 Mar</span>
													<div class="clearfix"></div>
													<span class="message-content">Lorem ipsum dolor sit amet, consectetur adipiscing</span>
												</div>
											</div>
										</a>
									</li>
									<li class="notification-message">
										<a href="chat">
											<div class="list-item">
												<div class="list-left">
													<span class="avatar">
														<img alt="" src="assets/img/profiles/avatar-03.jpg">
													</span>
												</div>
												<div class="list-body">
													<span class="message-author"> Tarah Shropshire </span>
													<span class="message-time">5 Mar</span>
													<div class="clearfix"></div>
													<span class="message-content">Lorem ipsum dolor sit amet, consectetur adipiscing</span>
												</div>
											</div>
										</a>
									</li>
									<li class="notification-message">
										<a href="chat">
											<div class="list-item">
												<div class="list-left">
													<span class="avatar">
														<img alt="" src="assets/img/profiles/avatar-05.jpg">
													</span>
												</div>
												<div class="list-body">
													<span class="message-author">Mike Litorus</span>
													<span class="message-time">3 Mar</span>
													<div class="clearfix"></div>
													<span class="message-content">Lorem ipsum dolor sit amet, consectetur adipiscing</span>
												</div>
											</div>
										</a>
									</li>
									<li class="notification-message">
										<a href="chat">
											<div class="list-item">
												<div class="list-left">
													<span class="avatar">
														<img alt="" src="assets/img/profiles/avatar-08.jpg">
													</span>
												</div>
												<div class="list-body">
													<span class="message-author"> Catherine Manseau </span>
													<span class="message-time">27 Feb</span>
													<div class="clearfix"></div>
													<span class="message-content">Lorem ipsum dolor sit amet, consectetur adipiscing</span>
												</div>
											</div>
										</a>
									</li>
								</ul>
							</div>
							<div class="topnav-dropdown-footer">
								<a href="chat">View all Messages</a>
							</div>
						</div>
					</li>
				-->
					<!-- /Message Notifications -->
	
					<li class="nav-item dropdown has-arrow main-drop">
						<a href="#" class="dropdown-toggle nav-link" data-toggle="dropdown">
							<span class="user-img"><img src="assets/img/profiles/avatar-21.jpg" alt="">
							<span class="status online"></span></span>
							<span>Admin</span>
						</a>
						<div class="dropdown-menu">
							<a class="dropdown-item" href="profile">My Profile</a>
							<a class="dropdown-item" href="settings">Settings</a>
							<a class="dropdown-item" href="logout">Logout</a>
						</div>
					</li>
				</ul>
				<!-- /Header Menu -->
				
				<!-- Mobile Menu -->
				<div class="dropdown mobile-user-menu">
					<a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="fa fa-ellipsis-v"></i></a>
					<div class="dropdown-menu dropdown-menu-right">
						<a class="dropdown-item" href="profile">My Profile</a>
						<a class="dropdown-item" href="settings">Settings</a>
						<a class="dropdown-item" href="logout">Logout</a>
					</div>
				</div>
				<!-- /Mobile Menu -->
				
            </div>

