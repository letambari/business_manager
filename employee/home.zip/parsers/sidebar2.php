 <div class="sidebar" id="sidebar">
                <div class="sidebar-inner slimscroll">
					<div class="sidebar-menu">
						<ul>
							<li> 
								<a href="home"><i class="la la-home"></i> <span>Back to Home</span></a>
							</li>
							<li class="menu-title">Settings</li>
							<li class="active"> 
								<a href="settings"><i class="la la-building"></i> <span>Company Settings</span></a>
							</li>
                       <!--
							<li> 
								<a href="localization"><i class="la la-clock-o"></i> <span>Localization</span></a>
							</li>
							<li> 
								<a href="theme-settings"><i class="la la-photo"></i> <span>Theme Settings</span></a>
							</li>
							<li> 
								<a href="roles-permissions"><i class="la la-key"></i> <span>Roles & Permissions</span></a>
							</li>
							<li> 
								<a href="email-settings"><i class="la la-at"></i> <span>Email Settings</span></a>
							</li>
							<li> 
								<a href="invoice-settings"><i class="la la-pencil-square"></i> <span>Invoice Settings</span></a>
							</li>
							<li> 
								<a href="salary-settings"><i class="la la-money"></i> <span>Salary Settings</span></a>
							</li>
							<li> 
								<a href="notifications-settings"><i class="la la-globe"></i> <span>Notifications</span></a>
							</li>
						-->
							<li> 
								<a href="change-password"><i class="la la-lock"></i> <span>Change Password</span></a>
							</li>
						<!--
							<li> 
								<a href="leave-type"><i class="la la-cogs"></i> <span>Leave Type</span></a>
							</li>
						-->
						</ul>
					</div>
                </div>
            </div>