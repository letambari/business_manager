

<!-- database conncection -->
<?php
 
 $con = mysqli_connect("localhost","root","","larajax");
 if(!$con){

    echo "failed to connect";
 }


 ?>